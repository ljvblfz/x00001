/*C����ͷ�ļ�*/

extern "C"
{

int __stdcall Set_Port(int zh,int jh,int port);  //pAgt.dll��

int __stdcall Detect_Fkj();                      //����pFkj.dll��
int __stdcall Get_Fkj_Type(char *s);
int __stdcall Get_Fkj_Ver(char *s);
int __stdcall Beep(int time);
int __stdcall Lamp(int time);
int __stdcall RFConfig(int mode,int baud);
int __stdcall RFRequest(int mode,int *tagtype);
int __stdcall RFAnticoll(int bcnt,unsigned int *snr);
int __stdcall RFSelect(unsigned int snr,int *size);
int __stdcall RFLoadKey(int mode,int secnr,char *nkey);
int __stdcall RFAuthentication(int mode,int secnr);
int __stdcall RFRead(int addr,char *data);
int __stdcall RFWrite(int addr,char *data);
int __stdcall RFHalt();
int __stdcall RFReset(int time);
int __stdcall RFReadA(unsigned int *snr,int addr,char *data,char *key);
int __stdcall RFWriteA(unsigned int snr,int addr,char *data,char *key);

}

