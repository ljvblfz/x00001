package io.vov.vitamio;

public class R {
	public static final class raw {
		public static final int libarm = com.broadsoft.xmeeting.R.raw.libarm;
		public static final int pub = com.broadsoft.xmeeting.R.raw.pub; 
	}
} 
