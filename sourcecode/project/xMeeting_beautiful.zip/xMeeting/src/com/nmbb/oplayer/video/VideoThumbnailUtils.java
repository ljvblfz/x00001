package com.nmbb.oplayer.video;

import android.graphics.Bitmap;

public final class VideoThumbnailUtils {
	
	/** 获取视频的缩略图 */
	public static Bitmap createVideoThumbnail() {
		return null;
	}

	/** 获取视频的时长 */
	public int getDuration() {
		return 1;
	}

	/** 获取视频的高度 */
	public int getVideoHeight() {
		return 1;
	}

	/** 获取视频的宽度 */
	public int getVideoWidth() {
		return 1;
	}
}
