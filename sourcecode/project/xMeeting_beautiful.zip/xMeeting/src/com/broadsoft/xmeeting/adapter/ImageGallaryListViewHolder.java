package com.broadsoft.xmeeting.adapter;

import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public final class ImageGallaryListViewHolder {
	public ImageView imagepreview;
	public TextView imagetitle;
	public TextView imageinfo;
	public Button imagemore;
}