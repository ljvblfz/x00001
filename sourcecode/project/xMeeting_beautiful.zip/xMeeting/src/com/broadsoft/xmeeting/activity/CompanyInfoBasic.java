package com.broadsoft.xmeeting.activity;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.broadsoft.xmeeting.R;

public class CompanyInfoBasic extends Activity {
 
 
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.company_basic); 
 
		 
	}
	 
	
	 
	
	 
}
