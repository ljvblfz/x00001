package com.broadsoft.appsupport;

import java.util.concurrent.ConcurrentHashMap;

public class SessionSupport {

	

	private static ConcurrentHashMap<String,Object>  variable=new ConcurrentHashMap<String,Object>();
	
}
