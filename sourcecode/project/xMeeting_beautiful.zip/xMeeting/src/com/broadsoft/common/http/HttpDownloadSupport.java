package com.broadsoft.common.http;

 

/**
 * http://dampce032.iteye.com/blog/975642
 * http://www.eoeandroid.com/thread-108676-1-1.html
 * http://blog.csdn.net/ameyume/article/details/6528205
 * 
 * @author lu.zhen
 *
 */
public class HttpDownloadSupport {

}
