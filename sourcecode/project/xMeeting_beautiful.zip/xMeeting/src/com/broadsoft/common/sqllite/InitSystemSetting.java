package com.broadsoft.common.sqllite;

public class InitSystemSetting {
	
	
	public void initSqlLite(){
		
		
	}

}
