package com.broadsoft.common.sqllite;




/**
 * http://www.20864.com/201247/274.html
 * @author lu.zhen
 *
 */
public class SqlLiteSupport {

	
	
}
